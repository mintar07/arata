FONTS CONFIGURATION:
\apache-tomcat\webapps\ROOT\VAADIN\themes\magnolia-icons\