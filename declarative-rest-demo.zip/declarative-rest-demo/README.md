## Rest client version 2 light module demo

In the rest client version 2.0 we have added some features to work with external rest api's.
Will be added to Magnolia in version 6.?.
You can define rest clients with a yaml file, and use that client in the ui or your pages.
Example definition in the **restClients** folder in our light modules:

```yaml
baseUrl: https://jsonplaceholder.typicode.com
restCalls:
  all:
    method: get
    entityClass: com.fasterxml.jackson.databind.JsonNode
    path: /posts
  single:
    method: get
    entityClass: com.fasterxml.jackson.databind.JsonNode
    path: /posts/{id}
  create:
    method: post
    entityClass: java.lang.String
    path: /posts
    body: {"userId": 1, "title": "{title}", "body": "{body}"}
    headers:
      Content-Type: "application/json; charset=UTF-8"
```

## Features

- Rest clients - with all their usages techniques
    - Using the template parameters and defaultValues
    - paging
    - caching
    - timeout
    - OpenAPI
- Rest client Authentication
    - basic
    - OAUTH2
    - (Other?)
- Template
- Template hitting a Magnolia deliveryEndpoint.
- JS Model

## Examples in this demo

In this demo we have a few examples, some applications with ui and some pages using rest definitions.

## Prerequisites

TODO Instructions to load this files

- To provide js model needed beans: load [config bootstrap](_install-manually/config.modules.javascript-models.config.yaml).
- To have demo example pages loaded in Pages app: load [website bootstrap](_install-manually/website.rest-client-demo.yaml).

## Page: posts

Show the list of posts. [Template](./templates/components/posts/posts.ftl) and [rest post definition](./restClients/posts.yaml)

## Page: post

Show a post, is used also from posts. [Template](./templates/components/post/post.ftl) and [rest post definition](./restClients/posts.yaml)

## Page: create-post

Create a post and show created, also using a js-model to work with rest client. [Js-model](./templates/components/create-post/create-post.js), [Template](./templates/components/create-post/create-post.ftl) and [rest post definition](./restClients/posts.yaml)

## Page: restfn-posts

Some examples using rest templates functions. Using the template parameters and defaultValues, also some timeout definitions are used [connect timeout](./restClients/connect-timeout.yaml) and [read timeout](./restClients/read-timeout.yaml).
An example using OpenAPI v3 with [pet store](https://petstore.swagger.io), used [definition](./restClients/pets.yaml).
[Template](./templates/components/restfn/restfn.ftl) and [rest restfn-posts definition](./restClients/restfn-posts.yaml)

## Page: countries

In this page we show shaved countries in countries app.
First, we have created a rest [endpoint](./restEndpoints/countries.yaml) to get the countries from jcr.
Then a [rest countries definition](./restClients/magnolia-stuff.yaml) with credentials and use in the [page](./templates/components/countries/countries.ftl).

## Page: books

Similar to create-post, but just search book by Isbn13 and show data back from rest api.
The [rest books definition](./restClients/books.yaml), the [template](./templates/components/books/books.ftl) and the [js-model](./templates/components/books/books.js).

## Bearer Authentication

TODO

## Caching

TODO

## Information on Magnolia CMS

This directory is a Magnolia 'light module'.
https://docs.magnolia-cms.com

## License
MIT

## Contributors
Magnolia, https://magnolia-cms.com