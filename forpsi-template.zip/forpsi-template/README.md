# forpsi-template - Bootstrap Templating Kit for Magnolia CMS

Create simple websites with Magnolia CMS and Bootstrap.

Developed on **Magnolia 6.2.7**. Using **Bootstrap 4.3.1**.

If something doesn’t work, please contact us:

- Tomáš Gregovský <tomas.gregovsky@magnolia-cms.com>
- Bartosz Staryga <bartosz.staryga@magnolia-cms.com>

## Installation

### Magnolia CLI

Run in Magnolia's folder:

```
mgnl install forpsi-template
```

or

### Git

Clone [forpsi-template repository](https://git.magnolia-cms.com/projects/LIGHT-MODULES/repos/forpsi-template/) into Magnolia's light modules folder.

## User Guide

When creating new page **Home [#forpsi-template]**, **Page [#forpsi-template]** and **Search [#forpsi-template]** templates will be available.

Use **Home [#forpsi-template]** for root page, **Page [#forpsi-template]** for subpages. **Search [#forpsi-template]** as a root child will enable search functionality.

### Demo page

Inside the module you can find **forpsi-template-Template** demo page that is fully build with forpsi-template. Demo page serves also as full documentation on forpsi-template's page templates and components.

To see demo page you have to:

- import `/forpsi-template/demo/dam.forpsi-template-Template.xml` into dam workspace (remember to import into folder and then move it to root)
- import `/forpsi-template/demo/website.forpsi-template-Template.xml` into website workspace

## What’s Included?

Your module will have everything you need to build a modern website with Magnolia CMS and Bootstrap.

Pages:

- Home
- Page
- Search

Components:

- Accordion
- Button
- Card
- Carousel
- Divider
- Heading
- Image
- Jumbotron
- Modal
- Row
- Text

## Source files

Compile Bootstrap with your own asset pipeline by using source Sass, JavaScript files in `webresources-src`.

Should you require build tools, they are included for developing Bootstrap.

```
npm i
npm run build
```

## Changelog


### 2.0.2 

- Updated dialogs definitions for new UI in Magnolia 6.2.x

### 2.0.1

- Bootstrap 4.3.1


## License

This project is open source software [licensed as MIT](https://git.magnolia-cms.com/projects/LIGHT-MODULES/repos/forpsi-template/browse/LICENSE).
