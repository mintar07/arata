
	
$('.sort').click(function () {
    $(".product").show();
    sortByPrice();
    if ($('.sort').hasClass('asc')) {
        $("#price-up-xs").show();
        $("#price-down-xs").hide();
    } else if ($('.sort').hasClass('desc')) {
        $("#price-up-xs").hide();
        $("#price-down-xs").show();
    }
});
$('#price-sort').click(function () {
    sortByPrice();
});
$('#price-ren-sort').click(function () {
    sortByRenPrice();
});
$('#price-sort-xs').click(function () {
    sortByPrice();
    if ($('.sort').hasClass('asc')) {
        $("#price-up-xs").show();
        $("#price-down-xs").hide();
    } else if ($('.sort').hasClass('desc')) {
        $("#price-up-xs").hide();
        $("#price-down-xs").show();
    }
});

$('#price-ren-sort-xs').click(function () {
    sortByRenPrice();
    if ($('#price-ren-sort').hasClass('asc')) {
        $("#price-ren-up-xs").show();
        $("#price-ren-down-xs").hide();
    } else if ($('#price-ren-sort').hasClass('desc')) {
        $("#price-ren-up-xs").hide();
        $("#price-ren-down-xs").show();
    }
});

function sortByPrice(){
  
    var $sort = $('#price-sort');
    var $table = $('#mytable');
    var $rows = $('tbody > tr.product', $table);
    $rows.sort(function (a, b) {
        var keyA = parseFloat($(a).data("price-for-sort").replace(",", "."));
        var keyB = parseFloat($(b).data("price-for-sort").replace(",", "."));
        if ($($sort).hasClass('asc')) {
            $("#price-up").show();
            $("#price-down").hide();
            return (keyA > keyB) ? 1 : -1 ;
        } else if ($($sort).hasClass('desc')) {
            $("#price-up").hide();
            $("#price-down").show();
            return (keyA > keyB) ? -1 : 1;
        }
    });
    $.each($rows, function (index, row) {
        $table.append(row);
    });
    if ($($sort).hasClass('asc')) {
        $($sort).removeClass('asc');
        $($sort).addClass('desc');}
    else {
        $($sort).removeClass('desc');
        $($sort).addClass('asc');}
};

function sortByRenPrice() {
    var $sort = $('#price-ren-sort');
    var $table = $('#mytable');
    var $rows = $('tbody > tr.product', $table);
    $rows.sort(function (a, b) {
        var keyA = parseFloat($(a).data("price-for-sort-ren").replace(",", "."));
        var keyB = parseFloat($(b).data("price-for-sort-ren").replace(",", "."));
        if ($($sort).hasClass('asc')) {
            $("#price-ren-up").show();
            $("#price-ren-down").hide();
            return (keyA > keyB) ? 1 : -1 ;
        } else if ($($sort).hasClass('desc')) {
            $("#price-ren-up").hide();
            $("#price-ren-down").show();
            return (keyA > keyB) ? -1 : 1;
        }
    });
    $.each($rows, function (index, row) {
        $table.append(row);
    });
    /*e.preventDefault();*/
    if ($($sort).hasClass('asc')) {
        $($sort).removeClass('asc');
        $($sort).addClass('desc');}
    else {
        $($sort).removeClass('desc');
        $($sort).addClass('asc');}
};

$('#tldsort').click(function() {
    var $tldsort = $('#tldsort');
    var $table = $('#mytable');
    var $rows = $('tbody > tr.product', $table);
    $rows.sort(function (c, d) {
        var keyC = $('td.newdomain strong', c).text();
        var keyD = $('td.newdomain strong', d).text();
        if ($($tldsort).hasClass('up')) {
            $("#tld-up").show();
            $("#tld-down").hide();
            return (keyC > keyD) ? 1 : -1 ;
        } else if ($($tldsort).hasClass('down')) {
            $("#tld-up").hide();
            $("#tld-down").show();
            return (keyC > keyD) ? -1 : 1;
        }
    });
    $.each($rows, function (index, row) {
        $table.append(row);
    });
    if ($($tldsort).hasClass('up')) {
        $($tldsort).removeClass('up');
        $($tldsort).addClass('down');}
    else {
        $($tldsort).removeClass('down');
        $($tldsort).addClass('up');}
});



/*
$( window ).load(function() {
  $(".popular").click();
  if (window.location.href.indexOf('#ceny-vsech-domen-dle-abecedy') > 0) {
       $(".ViewAll").click();
  }
});
$('#allview').click(function() {
  $(".ViewAll").click();
});

$(function () {
    var categories = Array();

   $('.ViewAll').click(function() {
        $(".product").show();
        $(".sort").removeClass('desc');
        $(".sort").addClass('asc');
       
    var $ViewAll = this;
    var $table = $('#mytable');
    var $rows = $('tbody > tr.product', $table);
    $rows.sort(function (c, d) {
        var keyC = $('td.newdomain strong', c).text();
        var keyD = $('td.newdomain strong', d).text();
        if ($($ViewAll).hasClass('up')) {
            return (keyC > keyD) ? 1 : -1 ;
        } 
    });
    $.each($rows, function (index, row) {
        $table.append(row);
    });
    
    });

    $('.Categories').click(function(){
        $(".sort").removeClass('desc');
        $(".sort").addClass('asc');

        var $Categories = this;
        var $table = $('#mytable');
        var $rows = $('tbody > tr.product', $table);
        $rows.sort(function (c, d) {
          var keyC = $('td.newdomain strong', c).text();
          var keyD = $('td.newdomain strong', d).text();
                return (keyC > keyD) ? 1 : -1 ;
        });
        $.each($rows, function (index, row) {
            $table.append(row);
        });

        if (!$(".btn-categories"+'[data-category-filter="national"]').hasClass('active')) {
          $(".btn-categories"+'[data-category-filter="national"]').click();
        }
        
        $('.product').hide();

        $('.product').each(function () {
            var row = $(this);

            var i;
            for (i = 0; i < categories.length; i++) {

                if (row.data('categories').includes(categories[i])) {
                    row.show();
                }

            }

        });

    });

    $(".btn-categories").click(function () {
        if ($(this).hasClass('active')) {
            $(this).removeClass('active');

            var filter = $(this).data("category-filter");

            categories = categories.filter(function (item) {
                return item !== filter
            });

        }
        else {
            $(this).addClass('active');
            var filter = $(this).data("category-filter");
            categories.push(filter);

        }

        $('.product').hide();

        $('.product').each(function () {
            var row = $(this);

            var i;
            for (i = 0; i < categories.length; i++) {

                if (row.data('categories').includes(categories[i])) {
                    row.show();
                }

            }



        });

    });

});
String.prototype.includes = function (str) {
  var returnValue = false;

  if (this.indexOf(str) !== -1) {
    returnValue = true;
  }

  return returnValue;
}



	
$('.popular').click(function (e) {
    $(".sort").removeClass('desc');
    $(".sort").addClass('asc');
    $(".product").hide();
    $(".product"+'[data-popular-index!="0"]').show();
    var $popular = this;
    var $table = $('#mytable');
    var $rows = $('tbody > tr.product', $table);
    $rows.sort(function (c, d) {
        var keyC = parseInt($(c).data("popular-index"));
        var keyD = parseInt($(d).data("popular-index"));
        if ($($popular).hasClass('up')) {
            return (keyC > keyD) ? 1 : -1 ;
        } else if ($($popular).hasClass('down')) {
            return (keyC > keyD) ? -1 : 1;
        }
    });
    $.each($rows, function (index, row) {
        $table.append(row);
    });
    e.preventDefault();
    if ($($popular).hasClass('up')) {
        $($popular).removeClass('up');
        $($popular).addClass('up');}
    else {
        $($popular).removeClass('down');
        $($popular).addClass('up');}
});

*/

