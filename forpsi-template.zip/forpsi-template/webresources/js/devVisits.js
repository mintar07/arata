  function setcurrencyCookie(currecyValue) {
      if(currecyValue == "eur" || currecyValue == "czk"){
      Cookies.set('currency', currecyValue, {
          expires: 365
      });
      document.location.href = document.location.origin + document.location.pathname;
    }

  }

  function removecurrencyCookie() {
      Cookies.remove('currency');
      document.location.href = document.location.origin + document.location.pathname + "?cache=0";
  }
